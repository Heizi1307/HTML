<?php

//
// Rick Mercer and YOUR NAME
//
// File MovieReport.php
//
// Read in a folder containing 8-20 .txt files holding movie data 
// and generate a report on that movie.
//

print ("Enter movie directory tmnt, tmnt2, mortalkombat, or princessbride: ");
$folder = readline ();

// If you have PHP 5, install XAMPP for Windows version 7 or use this line
//$folder = stream_get_line(STDIN,20 ,PHP_EOL);

// Need $movieDir in a a couple of functions below
$movieDir = $folder . '/';


printTitle ();  // Print the first three lines
printOverview (); // Print all elements in overview.txt
printReviews ();  // Print all reviews from the files review1.txt, review2.txt, review3.txt,  . . . 


function printTitle() {
   global $movieDir; // global provides access to the global variable $movieDir defined above
   echo $movieDir;
}

// Add other functions here
?>